# Booking UI — Contribution

A standalone, self-contained **Booking UI** component built with plain HTML/CSS/React
(no external libraries). Designed to drop into an existing hotel-app project.

## Files

- `BookingModal.jsx` — the component
- `BookingModal.css` — its styles

## What it does

1. Shows a summary of the selected hotel (image, name, location, price/night)
2. Lets the user pick **check-in / check-out dates**, **guests**, and **rooms**
3. Calculates nights, subtotal, taxes & fees, and total **live** as the user fills the form
4. Validates dates (check-out must be after check-in, can't book in the past)
5. Shows a **confirmation screen** with the full booking summary after submit

## How to add it to the project

1. Copy `BookingModal.jsx` and `BookingModal.css` into `src/components/`.
2. Import the CSS once, either in `BookingModal.jsx` itself:
   ```jsx
   import "./BookingModal.css";
   ```
   or in your global `index.css` via `@import "./components/BookingModal.css";`

3. Use it wherever a hotel's "Book Now" button lives — e.g. in a hotel details page
   or details modal:

   ```jsx
   import { useState } from "react";
   import BookingModal from "./components/BookingModal";

   function HotelDetails({ hotel }) {
     const [showBooking, setShowBooking] = useState(false);

     return (
       <>
         {/* ...hotel details UI... */}
         <button onClick={() => setShowBooking(true)}>Book Now</button>

         {showBooking && (
           <BookingModal
             hotel={hotel}
             onClose={() => setShowBooking(false)}
             onConfirm={(booking) => {
               console.log("Booking confirmed:", booking);
               // e.g. save to state, send to an API, etc.
             }}
           />
         )}
       </>
     );
   }
   ```

## Props

| Prop        | Type       | Required | Description                                                        |
|-------------|------------|----------|----------------------------------------------------------------------|
| `hotel`     | object     | ✅       | Needs `id`, `name`, `location`, `thumbnail`, `price`                |
| `onClose`   | function   | ✅       | Called when the modal is closed (X button or after confirming)      |
| `onConfirm` | function   | optional | Called with `{ hotelId, hotelName, checkIn, checkOut, nights, guests, rooms, total }` when the user confirms |

## Notes

- No external packages required — just React state (`useState`, `useMemo`).
- Works with whatever `hotel` object shape your team's API/listing already uses,
  as long as it has `name`, `location`, `thumbnail`, and `price`.
- This is a demo booking flow (no real payment/backend) — `onConfirm` is where
  you'd hook it up to an actual API if the project needs that later.
